var navLinks = document.getElementById("navLinks");

function showMenu() {
  navLinks.style.right = "0";

}

function hideMenu() {
  navLinks.style.right = "-200px";
}


document.addEventListener("DOMContentLoaded", function() {

  var backToTopButton = document.getElementById('back-to-top');
  
  
  window.onscroll = function() {
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
      backToTopButton.style.display = "block";
    } else {
      backToTopButton.style.display = "none";
    }
  };
  
  
  backToTopButton.addEventListener("click", function(e) {
    e.preventDefault();
    document.body.scrollTop = 0; 
    document.documentElement.scrollTop = 0; 
  });
});
